package reto4.model.dao;
import reto4.model.vo.ProyectosCampestresVo;
import java.util.List;
import java.sql.SQLException;
import java.sql.Connection;
import reto4.util.JDBCUtilities;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProyectosCampestresDao {
    //aquí hago la consulta de lo que me pidan-- lo guardo en un result set y lo recorro con el while
    public List<ProyectosCampestresVo> listar() throws SQLException{
        List<ProyectosCampestresVo> respuesta = new ArrayList<ProyectosCampestresVo>();
        Connection conn = JDBCUtilities.getConnection();
        Statement stm = null;
        ResultSet rs = null;
        String consulta = "SELECT ID_Proyecto as id, Constructora, Numero_Habitaciones as habitaciones, Ciudad from Proyecto p where Clasificacion = 'Casa Campestre' and ciudad in('Santa Marta', 'Cartagena', 'Barranquilla')";
        try{
            stm = conn.createStatement();
            rs = stm.executeQuery(consulta);
            while(rs.next()){
                ProyectosCampestresVo vo = new ProyectosCampestresVo();
                vo.setId(rs.getInt("id"));
                vo.setConstructora(rs.getString("constructora"));
                vo.setHabitaciones(rs.getInt("habitaciones"));
                vo.setCiudad(rs.getString("ciudad"));
                respuesta.add(vo);
            }
        }
        finally{
            if(rs != null){
                rs.close();
            }
            if(stm != null){
                stm.close();
            }
            if(conn != null){
                conn.close();
            }
        }
        return respuesta;
    }
}
