package reto4.controller;

import java.sql.SQLException;
import java.util.List;

import reto4.model.dao.*;
import reto4.model.vo.*;

//llamamos a los métodos que necesitamos de la vista
public class ReportesController {
    //atributos
    //modificador - tipo de objeto (string, integer o un objeto de una clase que yo haya creado) - nombre del objeto
    private ProyectosCampestresDao proyectosCampestresDao;
    private ListarLideresDao listarLideresDao;
    private ComprasDao deudasPorProyectoDao;
    
    public ReportesController() {
        proyectosCampestresDao = new ProyectosCampestresDao();
        listarLideresDao = new ListarLideresDao();
        deudasPorProyectoDao = new ComprasDao();
    }

    public List<ProyectosCampestresVo>listarProyectos() throws SQLException{
        return proyectosCampestresDao.listar();
    }
    public List<ListarLideresVo>listarLideres() throws SQLException{
        return listarLideresDao.listar();
    }
    public List<ComprasVo>listarCompras() throws SQLException{
        return deudasPorProyectoDao.listar();
    }
}
